#include<stdio.h>
#include<stdlib.h>
int n,m,alloc[10][10],max[10][10],ava[10],i,j,a,need[10][10];

void main()
{
	printf("Enter the no of process & resources ---->");
	scanf("%d%d",&n,&m);

	printf("Enter the max matrix\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
		scanf("%d",&max[i][j]);
		}
	
	}

	printf("Max Matrix\n");

	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("\t%d",max[i][j]);
		}
		printf("\n");
	}

	printf("\n_____________________________________________________________________\n\n");

	
	printf("Enter the allo matrix\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
		scanf("%d",&alloc[i][j]);
		}
	
	}

	printf("Alloc Matrix\n");

	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("\t%d",alloc[i][j]);
		}
		printf("\n");
	}

	printf("\n______________________________________________________________________\n\n");

	printf("Enter the size of available matrix --->");
	scanf("%d",&a);	
	printf("Enter the avail matrix\n");
	for(i=0;i<a;i++)
	{
		scanf("%d",&ava[i]);
		
	
	}

	printf("Available Matrix\n");

	for(i=0;i<a;i++)
	{
		
		
			printf("\t%d",ava[i]);
		
		
	}

	printf("\n__________________________________________________________________\n\n");


	printf("\nNeed Matrix\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("\t%d",max[i][j]-alloc[i][j]);
		}
		printf("\n");
	}
}


