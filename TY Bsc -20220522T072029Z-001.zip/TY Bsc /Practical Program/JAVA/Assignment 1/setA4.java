import java.util.*;

public class setA4
{
	public static void main(String args[])
	{
		Hashtable<Long,String>hashtable = new Hashtable<Long,String>();

		Scanner s = new Scanner(System.in);

		System.out.println("Enter how many number of Students you want");
		int n = s.nextInt();

		System.out.println("Enter Student Mobile no and Name");
		for(int i=0; i<n; i++)
		{
			hashtable.put(s.nextLong(), s.next());
		}
		
		System.out.println(hashtable);
	}
}
