import java.util.*;

class setA2{
  public static void main(String[] args) {
    ArrayList<String> friends = new ArrayList<>();
  Scanner s1=new Scanner(System.in);
  System.out.println("Enter a number of friend you want :");
  int n=s1.nextInt();
  System.out.println("Enter names of friend:");
for (int i=0;i<n;i++)
{  
     
       String input=s1.next();
    friends.add(input);
}

    System.out.println("ArrayList of frirnds : " +friends); 
  
  }
}
