import java.util.*;

public class setB2{


	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);

		HashMap<Integer, String> hm = new HashMap<Integer, String>();

		System.out.println("How many students: ");
 		int n = sc.nextInt();

		System.out.println("Enter Roll No and name: ");

		for(int i = 0; i < n;i++){
			hm.put(sc.nextInt(), sc.next());
		}

		TreeMap<Integer, String> tm = new TreeMap<Integer, String>(hm);

		System.out.println(tm);


	}

}
