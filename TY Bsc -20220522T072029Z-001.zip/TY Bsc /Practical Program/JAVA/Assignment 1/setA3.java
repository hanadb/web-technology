import java.util.*;
import java.util.TreeSet;

public class setA3
{
	public static void main(String args[])
	{
		Set<String> ts = new TreeSet<>();
		Scanner s = new Scanner(System.in);

		System.out.println("Enter how many color you want to enter");
		int n = s.nextInt();

		System.out.println("Enter color ");

		for(int i=0; i<n; i++)
		{
			ts.add(s.next());
		}

		
		System.out.println("Member from TreeSet" +ts);
		
	}
}
