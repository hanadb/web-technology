import java.io.*;
import java.lang.String.*;
class a3seta3 extends Thread
{
	String msg="";
	int n;
	a3seta3(String msg,int n)
	{
		this.msg=msg;
		this.n=n;
	}
	public void run()
	{
		try
		{
			for(int i=0;i<=n;i++)
			{
				System.out.println(msg+""+i+"times");
			}
		}
		catch(Exception e){}
	}
}
public class seta1
{
	public static void main(String args[])
	{
		a3seta3 t1 = new a3seta3("COVID 19",10);
		t1.start(); 
		a3seta3 t2 = new a3seta3("LOCKDOWN 2020",20);
		t2.start(); 
		a3seta3 t3 = new a3seta3("VACCINATED2021",30);
		t3.start(); 
	}
}
