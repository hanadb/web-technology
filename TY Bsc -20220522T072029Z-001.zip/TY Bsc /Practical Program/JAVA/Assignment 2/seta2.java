class a3 extends Thread
{
	String msg;
	a3(String msg)
	{
		this.msg = msg;
	}
	public void run()
	{
		try
		{
			for(int i=100;i>0;i--)
			{
				
				System.out.println(msg +"-->" +i);
				msg  ="hello";
				Thread.sleep(6000);
				msg = "hii";
			}
		}
		catch(Exception e)
		{}	
	}
}
public class seta2
	{
		public static void main(String args[])
		{
			a3 a = new a3("hello");
			a.start();
		}
	}
