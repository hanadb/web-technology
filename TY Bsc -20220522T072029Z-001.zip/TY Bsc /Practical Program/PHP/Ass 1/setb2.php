<?php
	session_start();
	$_SESSION["eid"] = $_POST["eno"];
	$_SESSION["enam"] = $_POST["enm"];
	$_SESSION["eadd"] = $_POST["add"];
	
	echo "Enter Earnings";
	echo "<form method = 'post' action = 'display.php'>";
	echo "<b>Enter Basics<input type = text name = 'bas'></b></br>";
	echo "<b>Enter DA<input type = text name = 'da'></b></br>";
	echo "<b>Enter HRA<input type = text name = 'hra'></b></br>";
	echo "<b><input type = submit value = 'Display'></b></br>";
	
?>
